 package com.cg.payroll.daoservices;


import java.util.ArrayList;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.payroll.beans.Associate;
public interface AssociateDAO extends JpaRepository<Associate, Integer> {
	/*
	Associate save(Associate associate) throws SQLException;
	
	ArrayList<Associate>  findAll() throws SQLException;
	
	Associate findOne(int associateId) throws SQLException;
	boolean update(Associate associate) throws SQLException;*/
	@Query("select a from Associate a where a.yearlyInvestmentUnder8oC <=:yearlyInvestmentUnder8oC")
	ArrayList<Associate> findFewAssociate(@Param("yearlyInvestmentUnder8oC") int yearlyInvestmentUnder8oC);
}