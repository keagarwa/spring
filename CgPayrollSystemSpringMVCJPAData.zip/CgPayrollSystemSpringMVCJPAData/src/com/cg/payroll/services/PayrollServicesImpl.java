package com.cg.payroll.services;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;

@Component("payrollServices")
public class PayrollServicesImpl implements PayrollServices {

	
	@Autowired
  AssociateDAO associateDAO;
	
	
	
	
@Override
	public Associate acceptAssociateDetails(Associate associate) throws PayrollServicesDownException {
		try {
			
			associate=associateDAO.save(associate);
		
			return associate;
		} catch (Exception e) {
			throw new PayrollServicesDownException("Payroll services down. Please try again.",e);
		}

	
	}

	@Override
	public int calculateNetSalary(int associateId)
			throws AssociateDetailsNotFoundException, PayrollServicesDownException {
		Associate associate;
		try {
			associate = associateDAO.findById(associateId).get();
			if(associate==null) throw new AssociateDetailsNotFoundException("Associate Details Not Found");
		} catch (Exception e) {
			throw new PayrollServicesDownException("Payroll Service down. Please try again");
		}

		//tax calculation code
		int basicSalary=associate.getSalary().getBasicSalary();

		int hra=50*basicSalary/100;
		associate.getSalary().setHra(hra);

		int conveyenceAllowance=25*basicSalary/100;
		associate.getSalary().setConveyenceAllowance(conveyenceAllowance);

		int otherAllowance=25*basicSalary/100;
		associate.getSalary().setOtherAllowance(otherAllowance);

		int personalAllowance=40*basicSalary/100;
		associate.getSalary().setPersonalAllowance(personalAllowance);

		int epf=12*basicSalary/100;
		associate.getSalary().setEpf(epf);

		int companyPf = 12*basicSalary/100;
		associate.getSalary().setCompanyPf(companyPf);

		int gratuity=481*basicSalary/10000;
		associate.getSalary().setGratuity(gratuity);

		int grossSalary=basicSalary+conveyenceAllowance+otherAllowance+personalAllowance+epf;
		associate.getSalary().setGrossSalary(grossSalary);
		int yearlyInvestmentUnder8oC = associate.getYearlyInvestmentUnder8oC();
		if(yearlyInvestmentUnder8oC+epf+companyPf>150000)
			yearlyInvestmentUnder8oC=150000-epf-companyPf;
		associate.setYearlyInvestmentUnder8oC(yearlyInvestmentUnder8oC);

		int taxableIncome = 12*(grossSalary-epf)-yearlyInvestmentUnder8oC;
		int yearlyTax=0;
		if(taxableIncome<=250000)
			yearlyTax=0;
		else if(taxableIncome>250000 && taxableIncome<=500000)
			yearlyTax=5*(taxableIncome-250000)/100;
		else if(taxableIncome>500000 && taxableIncome<=1000000)
			yearlyTax=12500+20*(taxableIncome-500000);
		else
			yearlyTax=112500+30*(taxableIncome-1000000);
		int monthlyTax=yearlyTax/12;
		associate.getSalary().setMonthlyTax(monthlyTax);

		int netSalary=grossSalary-epf-monthlyTax;
		associate.getSalary().setNetSalary(netSalary);
		System.out.println("Associate Id  "+associate.getAssociateID());
		try {  
			associate=associateDAO.save(associate);
		} catch (Exception e) {	
			throw new PayrollServicesDownException("Payroll Service down. Please try again");
		
		}
		return netSalary;
	}

	@Override
	public Associate getAssociateDetails(int associateId)
			throws AssociateDetailsNotFoundException, PayrollServicesDownException {
		Associate associate;
		try {
			associate = associateDAO.findById(associateId).get();
			if(associate==null) throw new AssociateDetailsNotFoundException("Associate Details Not Found");
		} catch (Exception e) {
			throw new PayrollServicesDownException("Payroll Service down. Please try again");
		}
		return associate;
	}

	@Override
	public ArrayList<Associate> getAllAssociatesDetails() throws PayrollServicesDownException {
		try {
			return (ArrayList<Associate>) associateDAO.findAll();
		} catch (Exception e) {
			throw new PayrollServicesDownException("Payroll Service down. Please try again");
		}
	}

	public PayrollServicesImpl() {
		super();
	}

	@Override
	public ArrayList<Associate> findFewAssociate(int yearlyInvestmentUnder8oC) {
		return associateDAO.findFewAssociate(yearlyInvestmentUnder8oC);
	}

	
}